local info={
	modVersion='2.0.3',
	modID='689638',
	modLink='https://gamebanana.com/mods/689638',
	modName='Xarlos Multiplayer',
	author='Xarlosgammer0FNF & Anthony',
	releaseDate='2026-07-26',
	features={
		'Multijugador local con WASD',
		'Bot para P2 configurable',
		'Ratings individuales',
		'Sistema de actualizaciones'
	},
	credits={
		'Base por Psych Engine Team',
		'Multijugador por Xarlosgammer0FNF',
		'HScript UI & Logica por Anthony'
	}
}
function info.getVer()
	return 'v'..info.modVersion
end
function info.getName()
	return info.modName..' '..info.getVer()
end
return info
