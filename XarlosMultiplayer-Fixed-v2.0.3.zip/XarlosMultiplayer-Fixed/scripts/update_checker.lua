local ver='2.0.3'
local modID='689638'
local link='https://gamebanana.com/mods/689638'
local popup=false
local checked=false
local newVer,newLink,changelog='','',''

function onCreate()
	initSaveData('xarlos_multiplayer')
	addHaxeLibrary('Http','haxe')
	addHaxeLibrary('Json','haxe.format')
end

function onCreatePost()
	makeLuaText('vText','v'..ver..' [U = Update]',0,10,700)
	setTextSize('vText',16)
	setTextFont('vText','vcr.ttf')
	setObjectCamera('vText','camOther')
	addLuaText('vText')
end

function onStateChangeEnd()
	if checked then return end
	local state=getProperty('stateName')
	if state=='TitleState' or state=='MainMenuState' then
		checked=true
		local last=getDataFromSave('xarlos_multiplayer','lastCheck')
		local today=os.date('%Y%m%d')
		if last~=today then
			runTimer('checkUpdate',2)
			setDataFromSave('xarlos_multiplayer','lastCheck',today)
			flushSaveData('xarlos_multiplayer')
		end
	end
end

function onUpdate(elapsed)
	if keyJustPressed('u') and not popup then
		checkUpdates(true)
	end
	if popup then
		if keyJustPressed('left') or keyJustPressed('a') or keyJustPressed('right') or keyJustPressed('d') then
			local sel=getProperty('btnSel')==0 and 1 or 0
			setProperty('btnSel',sel)
			if sel==0 then
				setProperty('bUp.color',0xFF7C4CE1)
				setProperty('bCan.color',0xFF353540)
			else
				setProperty('bUp.color',0xFF6C3CE1)
				setProperty('bCan.color',0xFF505060)
			end
		end
		if keyJustPressed('enter') then
			if getProperty('btnSel')==0 then
				runHaxeCode("FlxG.openURL('"..(newLink~='' and newLink or link).."');")
			end
			closePopup()
		elseif keyJustPressed('escape') then
			closePopup()
		end
	end
end

function onTimerCompleted(tag)
	if tag=='checkUpdate' then
		checkUpdates(false)
	end
end

function checkUpdates(manual)
	local url='https://gamebanana.com/apiv11/Mod/'..modID..'/Updates?_t='..getRandomInt(100,999)
	runHaxeCode([[
		var http=new haxe.Http("]]..url..[[");
		http.onData=function(data:String){
			try{
				var json=haxe.Json.parse(data);
				if(json._a!=null&&json._a.length>0){
					var last=json._a[0];
					var v=last._sVersion;
					var l=last._sDownloadUrl;
					var txt=last._sName;
					game.callOnLuas('gotUpdate',[v,l,txt]);
				}
			}catch(e:Dynamic){}
		};
		http.onError=function(e:String){};
		http.request();
	]])
end

function gotUpdate(v,l,txt)
	if v==ver then return end
	newVer=v
	newLink=l
	changelog=txt or ''
	showPopup()
end

function showPopup()
	popup=true
	setProperty('btnSel',0)
	makeLuaSprite('bgOver','',0,0)
	makeGraphic('bgOver',1280,720,'000000')
	setProperty('bgOver.alpha',0.7)
	setObjectCamera('bgOver','camOther')
	addLuaSprite('bgOver',true)
	makeLuaSprite('box','',240,160)
	makeGraphic('box',800,400,'1A1A2E')
	setObjectCamera('box','camOther')
	addLuaSprite('box',true)
	makeLuaText('t1','NUEVA ACTUALIZACION',800,240,190)
	setTextSize('t1',32)
	setTextFont('t1','vcr.ttf')
	setTextAlignment('t1','center')
	setObjectCamera('t1','camOther')
	addLuaText('t1')
	makeLuaText('t2','v'..ver..'  ->  v'..newVer,800,240,240)
	setTextSize('t2',20)
	setTextFont('t2','vcr.ttf')
	setTextAlignment('t2','center')
	setObjectCamera('t2','camOther')
	addLuaText('t2')
	makeLuaText('t3',changelog,720,280,290)
	setTextSize('t3',16)
	setTextFont('t3','vcr.ttf')
	setObjectCamera('t3','camOther')
	addLuaText('t3')
	makeLuaSprite('bUp','',300,480)
	makeGraphic('bUp',300,50,'7C4CE1')
	setObjectCamera('bUp','camOther')
	addLuaSprite('bUp',true)
	makeLuaText('bt1','DESCARGAR',300,300,495)
	setTextSize('bt1',20)
	setTextFont('bt1','vcr.ttf')
	setTextAlignment('bt1','center')
	setObjectCamera('bt1','camOther')
	addLuaText('bt1')
	makeLuaSprite('bCan','',680,480)
	makeGraphic('bCan',300,50,'353540')
	setObjectCamera('bCan','camOther')
	addLuaSprite('bCan',true)
	makeLuaText('bt2','CANCELAR',300,680,495)
	setTextSize('bt2',20)
	setTextFont('bt2','vcr.ttf')
	setTextAlignment('bt2','center')
	setObjectCamera('bt2','camOther')
	addLuaText('bt2')
end

function closePopup()
	popup=false
	removeLuaSprite('bgOver',true)
	removeLuaSprite('box',true)
	removeLuaSprite('bUp',true)
	removeLuaSprite('bCan',true)
	removeLuaText('t1',true)
	removeLuaText('t2',true)
	removeLuaText('t3',true)
	removeLuaText('bt1',true)
	removeLuaText('bt2',true)
end
