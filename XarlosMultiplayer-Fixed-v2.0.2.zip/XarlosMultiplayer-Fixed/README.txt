Xarlos Multiplayer - Fixed Edition v2.0.2
by Xarlosgammer0FNF

CONTROLES:
P1 = flechas
P2 = WASD

Activar bot P2: tecla 6

COMANDOS:
stats - muestra estadisticas
p2bot - activa/desactiva bot
p2color - cambia color del P2

INSTALACION:
1. Descomprimir en la carpeta mods
2. Activar desde el menu de mods
3. Jugar

Si crashea borra el settings.json y reinicia.

Creditos:
Xarlosgammer0FNF - codigo
Anthony - interfaz
Psych Engine Team - base

GameBanana: https://gamebanana.com/mods/689638
