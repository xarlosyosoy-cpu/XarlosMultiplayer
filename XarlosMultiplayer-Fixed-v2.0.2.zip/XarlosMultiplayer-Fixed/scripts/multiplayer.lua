keys = {'A', 'S', 'W', 'D'}

strumLock = false
dontHitIgnore = false
enableSetLua = true
enableRatings = true
showCombo = false
showComboNum = true
showRating = true
comboOffset = {-300, -250, -300, -250}
scoreTxtOffsetY = 0
cannotDieP1 = false
cannotDieP2 = false
healthDrainP1 = true
healthDrainP2 = true
missDrainP1 = true
missDrainP2 = true
doEndScreen = true
showResultsOnGameOver = true
doNoteSplashes = true
botPlayKey = 'SIX'
disableMiddleScroll = true
p2Color = 'FF4B4B'
p2ColorHex = 'FF4B4B'

p2Stats = {
    maxCombo = 0,
    sicks = 0,
    goods = 0,
    bads = 0,
    shits = 0,
    accuracy = 0
}

function loadSettings()
    local settingsFile = 'settings.json'
    if not fileExists(settingsFile) then return end
    local settingsData = jsonParse(loadFile(settingsFile))
    if not settingsData then return end
    local configMap = {
        botplayP2 = function(v) cpuControlled = v end,
        strumLock = function(v) strumLock = v end,
        dontHitIgnore = function(v) dontHitIgnore = v end,
        enableSetLua = function(v) enableSetLua = v end,
        enableRatings = function(v) enableRatings = v end,
        showCombo = function(v) showCombo = v end,
        showComboNum = function(v) showComboNum = v end,
        showRating = function(v) showRating = v end,
        cannotDieP1 = function(v) cannotDieP1 = v end,
        cannotDieP2 = function(v) cannotDieP2 = v end,
        healthDrainP1 = function(v) healthDrainP1 = v end,
        healthDrainP2 = function(v) healthDrainP2 = v end,
        missDrainP1 = function(v) missDrainP1 = v end,
        missDrainP2 = function(v) missDrainP2 = v end,
        doEndScreen = function(v) doEndScreen = v end,
        showResultsOnGameOver = function(v) showResultsOnGameOver = v end,
        doNoteSplashes = function(v) doNoteSplashes = v end,
        botPlayKey = function(v) botPlayKey = v end,
        disableMiddleScroll = function(v) disableMiddleScroll = v end
    }
    for _, setting in ipairs(settingsData) do
        if configMap[setting.save] then
            configMap[setting.save](setting.value)
        end
    end
end

loadSettings()
cpuControlled = false

local scoreP2, comboP2, totalPlayedP2, totalNotesHitP2 = 0, 0, 0, 0
local hitsP1, hitsP2, songMissesP2, noteMissesP2 = 0, 0, 0, 0
local ratingsP2 = {sicks = 0, goods = 0, bads = 0, shits = 0}
local ratingNameP2, ratingFCP2, ratingPercentP2 = '?', 'SFC', 1
local ratingCount, gfSinging = 0, false
local orMiddleScroll = nil
local deadP1, deadP2 = false, false

function onCreate()
    if type(_G["playbackRate"]) ~= 'number' then _G["playbackRate"] = 1 end
    addHaxeLibrary('FlxMath', 'flixel.math')
    addHaxeLibrary('Math')
    addHaxeLibrary('Std')
    orMiddleScroll = getPropertyFromClass('backend.ClientPrefs', 'data.middleScroll')
    if disableMiddleScroll then
        setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', false)
    end
end

function onCreatePost()
    if enableSetLua then
        setOnLuas("multiScript", true, true)
        setOnLuas("botplayP2", cpuControlled, true)
        setOnLuas("scoreP2", 0, true)
        setOnLuas("missesP2", 0, true)
        setOnLuas("noteMissesP2", 0, true)
        setOnLuas("comboP2", 0, true)
        setOnLuas("hitsP2", 0, true)
        setOnLuas("sicksP2", 0, true)
        setOnLuas("goodsP2", 0, true)
        setOnLuas("badsP2", 0, true)
        setOnLuas("shitsP2", 0, true)
        setOnLuas("ratingPercentP2", 1, true)
        setOnLuas("ratingNameP2", "?", true)
        setOnLuas("ratingFCP2", "SFC", true)
        setOnLuas("deadP2", false, true)
        setOnLuas("scrollTypeP1", getPropertyFromClass('backend.ClientPrefs', 'data.downScroll'), true)
        setOnLuas("scrollTypeP2", getPropertyFromClass('backend.ClientPrefs', 'data.downScroll'), true)
        setOnLuas("multiSwap", false, true)
        setOnLuas("multiStrumLock", strumLock, true)
        setOnLuas("multiSeparatedHealth", false, true)
        setOnLuas("multiNoIgnore", dontHitIgnore, true)
    end

    if enableRatings then
        local yPos = getPropertyFromClass('backend.ClientPrefs', 'data.downScroll') and (650 + scoreTxtOffsetY) or scoreTxtOffsetY
        makeLuaText('scoreTxtP2', 'Score: 0 | Misses: 0 | Rating: ?', 0, 0, yPos)
        addLuaText('scoreTxtP2', true)
        setObjectCamera('scoreTxtP2', 'camHUD')
        setProperty('scoreTxtP2.borderSize', 1.25)
        setTextSize('scoreTxtP2', getTextSize('scoreTxt'))
        setProperty('scoreTxtP2.font', getTextFont('scoreTxt'))
        setProperty('scoreTxtP2.color', getColorFromHex(p2Color))
        setProperty('scoreTxtP2.visible', getProperty('scoreTxt.visible'))
        setTextAlignment('scoreTxtP2', 'center')
        screenCenter('scoreTxtP2', 'x')
    end
end

function onUpdate(elapsed)
    if botPlayKey and botPlayKey ~= '' then
        if getPropertyFromClass('flixel.FlxG', 'keys.justPressed.'..botPlayKey:upper()) then
            cpuControlled = not cpuControlled
            if enableSetLua then
                setOnLuas("botplayP2", cpuControlled, true)
            end
        end
    end

    if not getPropertyFromClass('backend.ClientPrefs', 'data.noReset') and keyJustPressed('reset') and getProperty('canReset') and not getProperty('inCutscene') and not getProperty('endingSong') then
        if not cannotDieP1 and not deadP1 and showResultsOnGameOver then
            deadP1 = true
        end
    end
end

function onUpdatePost(elapsed)
    local songPos = getPropertyFromClass('backend.Conductor', 'songPosition')
    local safeOffset = getPropertyFromClass('backend.ClientPrefs', 'data.safeFrames') / 60 * 1000

    for i = getProperty('notes.length') - 1, 0, -1 do
        local mustPress = getPropertyFromGroup('notes', i, 'mustPress')
        if not mustPress then
            local strumTime = getPropertyFromGroup('notes', i, 'strumTime')
            local isSustain = getPropertyFromGroup('notes', i, 'isSustainNote')
            local hitByOpp = getPropertyFromGroup('notes', i, 'hitByOpponent')
            local noteData = getPropertyFromGroup('notes', i, 'noteData')
            local noteType = getPropertyFromGroup('notes', i, 'noteType')
            local earlyMult = isSustain and 0.5 or 1
            local lateMult = 1

            if strumTime > songPos - (safeOffset * lateMult) and strumTime < songPos + (safeOffset * earlyMult) then
                setPropertyFromGroup('notes', i, 'canBeHit', true)
            else
                setPropertyFromGroup('notes', i, 'canBeHit', false)
            end

            if strumTime < songPos - safeOffset and not hitByOpp then
                setPropertyFromGroup('notes', i, 'tooLate', true)
            end

            if cpuControlled and not getProperty('endingSong') then
                if getPropertyFromGroup('notes', i, 'rating') ~= 'ignore' and not hitByOpp then
                    if (isSustain and strumTime <= songPos + (safeOffset * earlyMult)) or (not isSustain and strumTime <= songPos) then
                        goodNoteHitP2(i)
                    end
                end
            end

            if songPos >= (getProperty('noteKillOffset') - 15) + strumTime then
                if not cpuControlled and getPropertyFromGroup('notes', i, 'rating') ~= 'ignore' and not getProperty('endingSong') and (getPropertyFromGroup('notes', i, 'tooLate') or not hitByOpp) then
                    noteMissP2(i, noteData, noteType, isSustain)
                end
                setPropertyFromGroup('notes', i, 'active', false)
                setPropertyFromGroup('notes', i, 'visible', false)
                removeFromGroup('notes', i)
            end
        end
    end

    if not cpuControlled and not getProperty('inCutscene') and not getProperty('endingSong') then
        input()
        holdInput()
    end

    if enableRatings and luaTextExists('scoreTxtP2') then
        local ratingStr = ratingNameP2
        if ratingPercentP2 >= 1 then
            ratingStr = ratingFCP2
        end
        setTextString('scoreTxtP2', 'Score: ' .. scoreP2 .. ' | Misses: ' .. songMissesP2 .. ' | Rating: ' .. ratingStr)
    end
end

function onSpawnNote(id)
    local isOpponent = not getPropertyFromGroup('notes', id, 'mustPress')
    if isOpponent then
        if getPropertyFromGroup('notes', id, 'ignoreNote') or getPropertyFromGroup('notes', id, 'hitCausesMiss') then
            setPropertyFromGroup('notes', id, 'rating', 'ignore')
        end
        if not healthDrainP2 then
            setPropertyFromGroup('notes', id, 'hitHealth', 0)
        end
        if not missDrainP2 then
            setPropertyFromGroup('notes', id, 'missHealth', 0)
        end
        setPropertyFromGroup('notes', id, 'ignoreNote', true)
    else
        if not healthDrainP1 then
            setPropertyFromGroup('notes', id, 'hitHealth', 0)
        end
        if not missDrainP1 then
            setPropertyFromGroup('notes', id, 'missHealth', 0)
        end
        setPropertyFromGroup('notes', id, 'rating', '')
    end
    if strumLock then
        setPropertyFromGroup('notes', id, 'copyAlpha', false)
    end
end

function input()
    for i, key in ipairs(keys) do
        local data = i - 1
        if i <= getProperty('opponentStrums.length') then
            if getPropertyFromClass('flixel.FlxG', 'keys.justPressed.'..key:upper()) then
                strumPlayAnim(data, 'pressed', true, -1)
                keyPress(data)
            end
            if getPropertyFromClass('flixel.FlxG', 'keys.justReleased.'..key:upper()) then
                strumPlayAnim(data, 'static', true, 0)
            end
        end
    end
end

function holdInput()
    for i, key in ipairs(keys) do
        local data = i - 1
        if i <= getProperty('opponentStrums.length') and getPropertyFromClass('flixel.FlxG', 'keys.pressed.'..key:upper()) then
            for id = 0, getProperty('notes.length')-1 do
                if getPropertyFromGroup('notes', id, 'isSustainNote') and not getPropertyFromGroup('notes', id, 'mustPress') and getPropertyFromGroup('notes', id, 'canBeHit') and not getPropertyFromGroup('notes', id, 'tooLate') and not getPropertyFromGroup('notes', id, 'hitByOpponent') and getPropertyFromGroup('notes', id, 'noteData') == data then
                    if not dontHitIgnore or (dontHitIgnore and getPropertyFromGroup('notes', id, 'rating') ~= 'ignore') then
                        goodNoteHitP2(id)
                    end
                end
            end
        end
    end
end

function keyPress(key)
    local songPos = getPropertyFromClass('backend.Conductor', 'songPosition')
    if songPos >= -(getProperty('noteKillOffset') - 15) and getProperty('startedCountdown') and not getProperty('paused') and key > -1 then
        if getProperty('generatedMusic') and not getProperty('endingSong') then
            local canMiss = not getPropertyFromClass('backend.ClientPrefs', 'data.ghostTapping')
            local sortedNotesList = {}
            for i = 0, getProperty('notes.length')-1 do
                if not getPropertyFromGroup('notes', i, 'mustPress') then
                    local canHit = getPropertyFromGroup('notes', i, 'canBeHit')
                    local hitByOpp = getPropertyFromGroup('notes', i, 'hitByOpponent')
                    local isSustain = getPropertyFromGroup('notes', i, 'isSustainNote')
                    local noteData = getPropertyFromGroup('notes', i, 'noteData')
                    if canHit and not hitByOpp and not isSustain and noteData == key then
                        if not dontHitIgnore or getPropertyFromGroup('notes', i, 'rating') ~= 'ignore' then
                            table.insert(sortedNotesList, i)
                        end
                    end
                end
            end
            if #sortedNotesList > 0 then
                table.sort(sortedNotesList, function(a, b)
                    return getPropertyFromGroup('notes', a, 'strumTime') < getPropertyFromGroup('notes', b, 'strumTime')
                end)
                goodNoteHitP2(sortedNotesList[1])
            elseif canMiss then
                noteMissPressP2(key)
            end
        end
    end
end

function goodNoteHitP2(id)
    if getPropertyFromGroup('notes', id, 'hitByOpponent') then return end
    local noteData = getPropertyFromGroup('notes', id, 'noteData')
    local noteType = getPropertyFromGroup('notes', id, 'noteType')
    local isSustain = getPropertyFromGroup('notes', id, 'isSustainNote')
    local altAnim = getProperty('SONG.notes['..getProperty('curSection')..'].altAnim')

    if getPropertyFromGroup('notes', id, 'hitCausesMiss') then
        if not getPropertyFromClass('backend.ClientPrefs', 'data.noteSplashData.disabled') and isSustain and doNoteSplashes then
            spawnNoteSplash(id)
        end
        if not getPropertyFromGroup('notes', id, 'noMissAnimation') and noteType == 'Hurt Note' then
            playAnim('dad', 'hurt', true)
            setProperty('dad.specialAnim', true)
        end
        setPropertyFromGroup('notes', id, 'hitByOpponent', true)
        setProperty('vocals.volume', 1)
        noteMissP2(id, noteData, noteType, isSustain)
        if not isSustain then
            removeFromGroup('notes', id)
        else
            setPropertyFromGroup('notes', id, 'ignoreNote', false)
        end
        return
    end

    if enableRatings and not isSustain then
        comboP2 = math.min(9999, comboP2 + 1)
        if comboP2 > p2Stats.maxCombo then
            p2Stats.maxCombo = comboP2
        end
        popUpScore(id)
    end

    if healthDrainP2 then
        local damage = getPropertyFromGroup('notes', id, 'hitHealth') * getProperty('healthGain')
        if getProperty('health') > damage then
            setProperty('health', getProperty('health') - damage)
        end
    end

    if not getPropertyFromGroup('notes', id, 'noAnimation') then
        local animToPlay = getProperty('singAnimations')[noteData + 1]
        local animSuffix = (noteType == 'Alt Animation' or altAnim) and '-alt' or getPropertyFromGroup('notes', id, 'animSuffix')
        if noteType == 'Hey!' then
            playAnim('dad', 'hey', true)
            setProperty('dad.specialAnim', true)
            setProperty('dad.heyTimer', 0.6)
            if getProperty('gf') ~= nil then
                playAnim('gf', 'cheer', true)
                setProperty('gf.specialAnim', true)
                setProperty('gf.heyTimer', 0.6)
            end
        else
            local char = (getPropertyFromGroup('notes', id, 'gfNote') and getProperty('gf') ~= nil) and 'gf' or 'dad'
            gfSinging = (char == 'gf')
            playAnim(char, animToPlay..animSuffix, true)
            if animSuffix ~= '' and getProperty(char..'.animation.curAnim.name') ~= animToPlay..animSuffix then
                playAnim(char, animToPlay, true)
            end
            setProperty(char..'.holdTimer', 0)
        end
    end

    local resetTime = cpuControlled and 0.15 or 0
    strumPlayAnim(noteData % getProperty('opponentStrums.length'), 'confirm', true, resetTime)
    setPropertyFromGroup('notes', id, 'hitByOpponent', true)
    setProperty('vocals.volume', 1)

    if enableSetLua then
        callOnLuas('opponentNoteHit', {id, noteData, noteType, isSustain}, false, true, {scriptName})
        callOnLuas('goodNoteHitP2', {id, noteData, noteType, isSustain}, false, true, {scriptName})
    end

    if not isSustain then
        removeFromGroup('notes', id)
    else
        setPropertyFromGroup('notes', id, 'ignoreNote', false)
    end
end

function noteMissP2(id, noteData, noteType, isSustainNote)
    if missDrainP2 then
        setProperty('health', getProperty('health') + (getPropertyFromGroup('notes', id, 'missHealth') * getProperty('healthLoss')))
    end
    setProperty('vocals.volume', 0)

    if not cannotDieP2 and not deadP2 and missDrainP2 and getProperty('health') <= 0 and showResultsOnGameOver then
        deadP2 = true
        if enableSetLua then
            setOnLuas("deadP2", true, true)
        end
    end

    if enableRatings then
        comboP2 = 0
        if not getProperty('endingSong') then
            songMissesP2 = songMissesP2 + 1
            noteMissesP2 = noteMissesP2 + 1
        end
        if not getProperty('practiceMode') then
            scoreP2 = scoreP2 - 10
        end
        totalPlayedP2 = totalPlayedP2 + 1
        RecalculateRating(true)
        if enableSetLua then
            setOnLuas("comboP2", 0, true)
            setOnLuas("missesP2", tonumber(songMissesP2), true)
            setOnLuas("noteMissesP2", tonumber(noteMissesP2), true)
            setOnLuas("scoreP2", tonumber(scoreP2), true)
        end
    end

    local char = (getPropertyFromGroup('notes', id, 'gfNote') and getProperty('gf') ~= nil) and 'gf' or 'dad'
    if getProperty(char..'.hasMissAnimations') then
        local animToPlay = getProperty('singAnimations')[noteData + 1]..'miss'
        local animSuffix = (noteType == 'Alt Animation') and '-alt' or getPropertyFromGroup('notes', id, 'animSuffix')
        playAnim(char, animToPlay..animSuffix, true)
        if animSuffix ~= '' and getProperty(char..'.animation.curAnim.name') ~= animToPlay..animSuffix then
            playAnim(char, animToPlay, true)
        end
        setProperty(char..'.specialAnim', true)
    end

    if enableSetLua then
        callOnLuas('noteMissP2', {id, noteData, noteType, isSustainNote}, false, true, {scriptName})
    end
end

function noteMissPressP2(direction)
    if missDrainP2 then
        setProperty('health', getProperty('health') + (0.05 * getProperty('healthLoss')))
    end
    setProperty('vocals.volume', 0)

    if not cannotDieP2 and not deadP2 and missDrainP2 and getProperty('health') <= 0 and showResultsOnGameOver then
        deadP2 = true
        if enableSetLua then
            setOnLuas("deadP2", true, true)
        end
    end

    if enableRatings then
        comboP2 = 0
        if not getProperty('endingSong') then
            songMissesP2 = songMissesP2 + 1
            noteMissesP2 = noteMissesP2 + 1
        end
        if not getProperty('practiceMode') then
            scoreP2 = scoreP2 - 10
        end
        totalPlayedP2 = totalPlayedP2 + 1
        RecalculateRating(true)
        if enableSetLua then
            setOnLuas("comboP2", 0, true)
            setOnLuas("missesP2", tonumber(songMissesP2), true)
            setOnLuas("noteMissesP2", tonumber(noteMissesP2), true)
            setOnLuas("scoreP2", tonumber(scoreP2), true)
        end
    end
end

function popUpScore(id)
    local noteDiff = math.abs(getPropertyFromGroup('notes', id, 'strumTime') - getPropertyFromClass('backend.Conductor', 'songPosition') * getProperty('playbackRate'))
    local score = 350
    local daRating = 'sick'

    if noteDiff > getPropertyFromClass('backend.ClientPrefs', 'data.sickWindow') then
        if noteDiff > getPropertyFromClass('backend.ClientPrefs', 'data.goodWindow') then
            if noteDiff > getPropertyFromClass('backend.ClientPrefs', 'data.badWindow') then
                daRating = 'shit'
                score = 50
                ratingsP2.shits = ratingsP2.shits + 1
            else
                daRating = 'bad'
                score = 100
                ratingsP2.bads = ratingsP2.bads + 1
            end
        else
            daRating = 'good'
            score = 200
            ratingsP2.goods = ratingsP2.goods + 1
        end
    else
        ratingsP2.sicks = ratingsP2.sicks + 1
    end

    if not getProperty('practiceMode') and not getProperty('cpuControlled') then
        scoreP2 = scoreP2 + score
        totalNotesHitP2 = totalNotesHitP2 + 1
        totalPlayedP2 = totalPlayedP2 + 1
        hitsP2 = hitsP2 + 1
    end

    RecalculateRating(false)

    if enableSetLua then
        setOnLuas("scoreP2", tonumber(scoreP2), true)
        setOnLuas("comboP2", tonumber(comboP2), true)
        setOnLuas("hitsP2", tonumber(hitsP2), true)
        setOnLuas("sicksP2", tonumber(ratingsP2.sicks), true)
        setOnLuas("goodsP2", tonumber(ratingsP2.goods), true)
        setOnLuas("badsP2", tonumber(ratingsP2.bads), true)
        setOnLuas("shitsP2", tonumber(ratingsP2.shits), true)
    end
end

function RecalculateRating(badHit)
    if totalPlayedP2 < 1 then
        ratingNameP2 = '?'
        ratingPercentP2 = 1
    else
        ratingPercentP2 = math.min(1, math.max(0, totalNotesHitP2 / totalPlayedP2))
        if ratingPercentP2 >= 0.999 then
            ratingNameP2 = 'Perfect!!'
            ratingFCP2 = 'SFC'
        elseif ratingPercentP2 >= 0.99 then
            ratingNameP2 = 'Sick!'
            ratingFCP2 = 'GFC'
        elseif ratingPercentP2 >= 0.98 then
            ratingNameP2 = 'Sick!'
            ratingFCP2 = 'FC'
        elseif ratingPercentP2 >= 0.95 then
            ratingNameP2 = 'Sick!'
            ratingFCP2 = 'FC'
        elseif ratingPercentP2 >= 0.9 then
            ratingNameP2 = 'Great'
            ratingFCP2 = 'FC'
        elseif ratingPercentP2 >= 0.8 then
            ratingNameP2 = 'Good'
            ratingFCP2 = 'FC'
        elseif ratingPercentP2 >= 0.7 then
            ratingNameP2 = 'Nice'
            ratingFCP2 = 'FC'
        elseif ratingPercentP2 >= 0.6 then
            ratingNameP2 = 'Meh'
            ratingFCP2 = 'FC'
        else
            ratingNameP2 = 'Bruh'
            ratingFCP2 = 'FC'
        end
        if songMissesP2 > 0 then
            if songMissesP2 < 10 then
                ratingFCP2 = 'SDCB'
            else
                ratingFCP2 = 'Clear'
            end
        end
    end
    if enableSetLua then
        setOnLuas("ratingPercentP2", ratingPercentP2, true)
        setOnLuas("ratingNameP2", ratingNameP2, true)
        setOnLuas("ratingFCP2", ratingFCP2, true)
    end
end

function strumPlayAnim(id, anim, forced, resetTime)
    if id < 0 or id >= getProperty('opponentStrums.length') then return end
    setPropertyFromGroup('opponentStrums', id, 'animation.curAnim.name', anim)
    if forced then
        playAnim('opponentStrums', anim, true, false, id)
    end
    if resetTime and resetTime > 0 then
        runTimer('strumReset'..id, resetTime)
    end
end

function onTimerCompleted(tag)
    if string.sub(tag, 1, 10) == 'strumReset' then
        local id = tonumber(string.sub(tag, 11))
        if id then
            setPropertyFromGroup('opponentStrums', id, 'animation.curAnim.name', 'static')
        end
    end
end

function onDestroy()
    if disableMiddleScroll and orMiddleScroll ~= nil then
        setPropertyFromClass('backend.ClientPrefs', 'data.middleScroll', orMiddleScroll)
    end
end

function onEndSong()
    if doEndScreen then
        p2Stats.accuracy = ratingPercentP2
        p2Stats.sicks = ratingsP2.sicks
        p2Stats.goods = ratingsP2.goods
        p2Stats.bads = ratingsP2.bads
        p2Stats.shits = ratingsP2.shits
    end
    return Function_Continue
end
